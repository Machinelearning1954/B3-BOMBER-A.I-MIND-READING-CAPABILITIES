"""
Neural Interface & Mind Reading Technology Module

This module implements advanced brain-computer interface (BCI) systems for
mind reading and language interpretation capabilities. It integrates:

- EEG/fMRI signal processing for neural activity monitoring
- Neural language decoding from brain signals
- Thought-to-text translation systems
- Cognitive state assessment and prediction
- Real-time neural feedback systems
- Multi-modal brain signal fusion

The technology enables direct neural communication and thought interpretation
for enhanced human-machine collaboration in defense applications.
"""

from .bci_core import BrainComputerInterface
from .neural_decoder import NeuralLanguageDecoder
from .thought_translator import ThoughtToTextTranslator
from .cognitive_monitor import CognitiveStateMonitor
from .signal_processor import NeuralSignalProcessor
from .language_interpreter import NeuralLanguageInterpreter
from .mind_reader import AdvancedMindReader

__all__ = [
    "BrainComputerInterface",
    "NeuralLanguageDecoder",
    "ThoughtToTextTranslator", 
    "CognitiveStateMonitor",
    "NeuralSignalProcessor",
    "NeuralLanguageInterpreter",
    "AdvancedMindReader"
]

