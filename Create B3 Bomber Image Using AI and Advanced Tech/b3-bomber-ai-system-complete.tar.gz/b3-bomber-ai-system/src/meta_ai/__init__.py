"""
Meta AI Integration Module

This module provides integration with Meta AI's state-of-the-art models including:
- LLaMA 2/3 for advanced language understanding and generation
- SAM (Segment Anything Model) for precise image segmentation
- CLIP for multi-modal vision-language understanding
- DINO for self-supervised vision transformers

All models are optimized for defense intelligence applications with
specialized fine-tuning and domain adaptation.
"""

from .llama import LLaMAProcessor
from .sam import SegmentAnythingProcessor
from .clip import CLIPProcessor
from .dino import DINOProcessor
from .system import MetaAISystem

__all__ = [
    "LLaMAProcessor",
    "SegmentAnythingProcessor", 
    "CLIPProcessor",
    "DINOProcessor",
    "MetaAISystem"
]

